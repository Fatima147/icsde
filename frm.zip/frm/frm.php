<?php
require_once('vendor/autoload.php');
ob_start();
?>
<page>
<div style="position:relative;margin: 48px 0px 170px 42px;padding: 0px;border: none;width: 752px;">
	<div style="border:none;margin: 0px 0px 0px 0px;padding: 0px;border:none;width: 752px;">
		<p style="text-align: left;margin-top: 0px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Paper ID: <?php echo $_GET['paper'];?></p>
		<p style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</p>
		<p style="text-align: left;padding-left: 262px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">PERSONAL INFORMATION</p>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
		<P style="text-align: left;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Full Name : <?php echo $_GET['fname']." ".$_GET['lname'];?></P>
		<P style="text-align: left;margin-top: 20px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Email : <?php echo $_GET['email'];?></P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Address : <?php echo $_GET['address'];?></P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">City/Country : <?php echo $_GET['city']." ".$_GET['country'];?></P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Zip Code (Postal Code): <?php echo $_GET['postCode'];?></P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Phone : <?php echo $_GET['tel'];?></P>
		<P style="text-align: left;margin-top: 20px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Affiliation : <?php echo $_GET['affiliation'];?></P>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
		<P style="text-align: left;padding-left: 246px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">REGISTRATION INFORMATION</P>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
		<P style="text-align: left;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Registration Type : <?php

if ($_GET['RegistrationType']=='1'){

	echo 'Registration only';

}else if ($_GET['RegistrationType']=='2'){

	echo 'The proceedings, lunches, and coffee breaks';

}else if ($_GET['RegistrationType']=='3'){

	echo 'Hotel for two days, the proceedings, lunches, and coffee breaks.';

}

?>
</P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Additional paper(s) : <?php echo $_GET['additionalpaper'];?></P>
		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Additional page(s) : <?php echo $_GET['additionalpage'];?></P>
		<P style="text-align: left;margin-top: 20px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Additional CD(s) : <?php echo $_GET['additionalcd'];?></P>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
		<P style="text-align: left;padding-left: 319px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">PAYMENT</P>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
		<P style="text-align: left;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Payment method : <?php echo $_GET['payment'];?></P>
<?php

$devis="Euro";

$today = date("m-d-y ");

$time_limit = strtotime('07/05/2017');

$country=$_GET['country'];

$RegistrationType=(int)$_GET['RegistrationType'];

$additionalpaper=(int)$_GET['additionalpaper'];

$additionalpage=(int)$_GET['additionalpage'];

$additionalcd=(int)$_GET['additionalcd'];

$totlale=0;

if ($RegistrationType==1){

	$totlale=220;

}else if ($RegistrationType==2){

	$totlale=270;

}else if ($RegistrationType==3){

	$totlale=420;

}

if ($today >= $time_limit){
    $totlale=$totlale+50;
}
	
if($additionalpaper!=0){
	
	if ($today < $time_limit){
		
		$totlale=$totlale+$additionalpaper*220;
		
	}else{
		
		$totlale=$totlale+$additionalpaper*270;
	}
}

if($additionalpage!=0){
	$totlale=$totlale+$additionalpage*20;
}

if($additionalcd!=0){
	$totlale=$totlale+$additionalcd*20;
}

if($country=="Morocco"){
	$totlale=$totlale*10;
	$devis="Dirhams";
}

?>

		<P style="text-align: left;margin-top: 21px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">Total amount : <?php echo $totlale." ".$devis;?> </P>
		<P style="text-align: left;padding-left: 1px;margin-top: 2px;margin-bottom: 0px; font: 15px 'Helvetica';line-height: 17px;">----------------------------------------------------------------------------------------------------------------------------------------------------------------</P>
<div style="text-align: center	;padding-left: 10px;margin-top: 1px;margin-bottom: 0px; font: 15px 'Helvetica'">
<p>
Account name : (RIDE) Centre de recherche et d'innovation pour développement et l'entrepreneuriat <br>
Account number : 00 0071 B 000 358 569 <br>
R.I.B : 007 810 0000 712 000 358 569 64 <br>
SWIFT code : BCMAMAMC <br><br>
Bank Name : Attijariwafa Bank<br>
Address : Rabat Av Témara - Code 0071<br>
Phone   : 00212 537 720 857<br>
Fax     : 00212 537 723 934 <br>
</p>
</div>
<div style="text-align: center;margin-top: 1px;margin-bottom: 0px; font: 15px 'Helvetica'">
<p>** All bank transfer fees are at congressist charge. **<br>
To accomplish your registration in the ICSDE'18, please save this Registration Form (PDF file)<br>
and send it with a copy of your bank transfer receipt to icsde.bank@gmail.com
<br>
However, you must bring these original documents with you to complete and validate your conference registration. 
<br>
----------------------------------------------------------------------------------------------------------------------------------------------------------------<br>
</p>
</div>
	</div>
	<div style="border:none;margin: 21px 0px 0px 0px;padding: 0px;border:none;width: 752px;">
<p style="text-align: left;margin-top: 0px;margin-bottom: 0px;font: 15px 'Helvetica';line-height: 17px;">Done at <?php echo date('M j, Y', time());?></p>
	</div>
</div>
</page>
<?php
$content = ob_get_clean();
$html2pdf = new HTML2PDF('P', 'A4', 'fr', true, 'UTF-8', 0);
$html2pdf->writeHTML($content);
$html2pdf->Output('exemple08.pdf');
?>
